// auth.js - Runs on your React website (localhost or live)
// Grabs the token and sends it to the extension's background script

function syncTokenToExtension() {
    const token = localStorage.getItem('token');
    
    if (token) {
        // Tell the extension who is currently logged in
        chrome.runtime.sendMessage({ action: "SAVE_AUTH_TOKEN", token: token });
    } else {
        // If they log out, tell the extension to stop syncing
        chrome.runtime.sendMessage({ action: "LOGOUT_EXTENSION" });
    }
}

// Check immediately on page load
syncTokenToExtension();

// Check periodically in case they log in/out without refreshing the page
setInterval(syncTokenToExtension, 2000);