// auth.js - Runs on your React website (localhost or live)
// Grabs the token and sends it to the extension's background script

function syncTokenToExtension() {
    const token = localStorage.getItem('token');
    
    try {
        if (token) {
            chrome.runtime.sendMessage({ action: "SAVE_AUTH_TOKEN", token: token });
        } else {
            chrome.runtime.sendMessage({ action: "LOGOUT_EXTENSION" });
        }
    } catch (error) {
        // If the extension was reloaded, catch the invalid context error silently
        if (error.message.includes("Extension context invalidated")) {
            console.warn("MyPortal Extension updated. Please refresh this page to re-sync.");
        }
    }
}

// Check immediately on page load
syncTokenToExtension();

// Check periodically in case they log in/out without refreshing the page
setInterval(syncTokenToExtension, 2000);