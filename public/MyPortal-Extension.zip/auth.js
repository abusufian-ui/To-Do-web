// auth.js - Runs on your React website (localhost or live)

let syncInterval; // Store the interval ID

function syncTokenToExtension() {
    const token = localStorage.getItem('token');
    
    try {
        if (chrome.runtime && chrome.runtime.sendMessage) {
            if (token) {
                chrome.runtime.sendMessage({ action: "SAVE_AUTH_TOKEN", token: token });
            } else {
                chrome.runtime.sendMessage({ action: "LOGOUT_EXTENSION" });
            }
        }
    } catch (error) {
        // If the extension was reloaded, catch the invalid context error
        if (error.message.includes("Extension context invalidated")) {
            console.warn("MyPortal Extension updated. Stopping sync until page refresh.");
            // KILL THE INTERVAL SO IT STOPS SPAMMING REACT'S ERROR OVERLAY
            clearInterval(syncInterval); 
        }
    }
}

// Check immediately on page load
syncTokenToExtension();

// Check periodically, but save the ID so we can stop it if the extension reloads
syncInterval = setInterval(syncTokenToExtension, 2000);