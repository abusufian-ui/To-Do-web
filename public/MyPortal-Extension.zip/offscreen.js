chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "RUN_SCRAPE") {
        runExtraction()
            .then(data => sendResponse(data))
            .catch(err => sendResponse({ error: err.message }));
        return true; 
    }
});

async function runExtraction() {
    console.log("Starting bulletproof background extraction on UCP Horizon...");
    
    let portalId = null;
    const courseLinks = [];
    const courseMap = new Map();
    let exactInProgressCr = 0;

    // --- STRICT IDENTITY EXTRACTION ---
    try {
        const dashRes = await fetch('https://horizon.ucp.edu.pk/student/dashboard');
        if (dashRes.url.includes("login") || !dashRes.ok) {
            throw new Error("Student is logged out of Horizon. Please log in to UCP first.");
        }
        const dashHtml = await dashRes.text();
        
        // --- THE FIX: Parse HTML to ignore scripts, tags, and hidden hashes ---
        const dashDoc = new DOMParser().parseFromString(dashHtml, 'text/html');
        const cleanPageText = dashDoc.body.textContent; 
        
        const idRegex = /[a-zA-Z]\d[a-zA-Z]\d{2}[a-zA-Z]+\d{3,4}/i; 
        
        // Run regex ONLY on the clean text, not the raw HTML
        const match = cleanPageText.match(idRegex); 
        
        if (match) {
            portalId = match[0].toUpperCase();
            console.log(`🔒 Identity Lock: Found Portal ID [${portalId}]`);
        } else {
            console.log("⚠️ Warning: Could not detect Portal ID on dashboard.");
            throw new Error("Could not detect Portal ID.");
        }
    } catch (e) {
        throw new Error(e.message || "Failed to access UCP Dashboard.");
    }

    // --- FETCH ENROLLED COURSES & EXACT CREDITS ---
    try {
        console.log("Fetching exact enrolled courses and credits...");
        const enrolledRes = await fetch('https://horizon.ucp.edu.pk/student/enrolled/courses');
        const enrolledHtml = await enrolledRes.text();
        const enrolledDoc = new DOMParser().parseFromString(enrolledHtml, 'text/html');

        enrolledDoc.querySelectorAll('a[href*="/student/course/"]').forEach(el => {
            let href = el.getAttribute('href');
            if (!href) return;
            
            if (!href.startsWith('http')) href = 'https://horizon.ucp.edu.pk' + href;
            
            if (!courseLinks.includes(href)) {
                courseLinks.push(href);
            }

            const nameSpan = el.querySelector('span.md-list-heading');
            if (nameSpan) {
                let fullText = nameSpan.textContent.trim();
                let courseCode = "";
                let courseName = fullText;

                const codeRegex = /^([a-zA-Z]{2,5}[-\s]?\d{3,4})\s*[-:]?\s*(.*)$/;
                const codeMatch = fullText.match(codeRegex);
                
                if (codeMatch) {
                    courseCode = codeMatch[1].trim().toUpperCase();
                    courseName = codeMatch[2].trim(); 
                }
                
                let credits = 3.0; 
                const subHeadings = el.querySelectorAll('span.sub-heading');
                subHeadings.forEach(sh => {
                    if (sh.textContent.includes('Credits:')) {
                        const credText = sh.textContent.replace('Credits:', '').trim();
                        credits = parseFloat(credText) || 0;
                    }
                });

                exactInProgressCr += credits;
                courseMap.set(href, { name: courseName, code: courseCode, credits: credits });
            }
        });
    } catch (e) {
        console.error("Failed to fetch exact enrolled courses:", e);
    }

    // ==========================================
    // TASK 1: FETCH GRADES
    // ==========================================
    const scrapeGrades = async () => {
        let gradesData = [];
        for (const url of courseLinks) {
            try {
                const response = await fetch(url);
                const htmlText = await response.text();
                
                const parser = new DOMParser();
                const doc = parser.parseFromString(htmlText, 'text/html');

                const realName = courseMap.has(url) ? courseMap.get(url).name : (doc.querySelector('.breadcrumb li:nth-child(2)')?.textContent.trim() || "Unknown Course");
                const results = [];

                doc.querySelectorAll('tr.table-parent-row').forEach(row => {
                    const nameAnchor = row.querySelector('a.toggle-childrens');
                    let summaryName = "Unknown";
                    let weightValue = "";

                    if (nameAnchor) {
                        let rawText = "";
                        nameAnchor.childNodes.forEach(node => {
                            if (node.nodeType === 3) { 
                                rawText += node.textContent;
                            }
                        });
                        summaryName = rawText.replace(/\s+/g, ' ').trim() || "Unknown";
                        
                        const badge = nameAnchor.querySelector('.uk-badge');
                        if (badge) {
                            weightValue = badge.textContent.replace(/\s+/g, '').trim(); 
                        }
                    }
                    
                    const tds = row.querySelectorAll('td');
                    let summaryPercentage = tds.length >= 2 ? tds[1].textContent.trim() : "0";

                    let childDetails = [];
                    let nextSibling = row.nextElementSibling;
                    
                    while (nextSibling && !nextSibling.classList.contains('table-parent-row')) {
                        const childTds = nextSibling.querySelectorAll('td');
                        if (childTds.length >= 5) {
                            childDetails.push({
                                name: childTds[0].textContent.trim(),
                                maxMarks: childTds[1].textContent.trim(),
                                obtainedMarks: childTds[2].textContent.trim(),
                                classAverage: childTds[3].textContent.trim(),
                                percentage: childTds[4].textContent.trim()
                            });
                        }
                        nextSibling = nextSibling.nextElementSibling;
                    }
                    results.push({ name: summaryName, weight: weightValue, percentage: summaryPercentage, details: childDetails });
                });

                const totalBadge = doc.evaluate("//span[contains(@class, 'uk-badge') and contains(text(), '/ 100')]", doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                const totalPercentage = totalBadge ? totalBadge.textContent.split('/')[0].trim() : "0";

                gradesData.push({ courseUrl: url, courseName: realName, assessments: results, totalPercentage: totalPercentage });
                
            } catch (e) {
                console.error(`Skipped active course details for ${url}:`, e);
            }
        }
        return gradesData;
    };

    // ==========================================
    // TASK 2: FETCH HISTORY & STATS
    // ==========================================
    const scrapeHistory = async () => {
        const historyData = [];
        let statsData = { cgpa: "0.00", credits: "0", inprogressCr: exactInProgressCr.toString() };

        try {
            const historyResponse = await fetch('https://horizon.ucp.edu.pk/student/results');
            const historyHtml = await historyResponse.text();
            const hParser = new DOMParser();
            const hDoc = hParser.parseFromString(historyHtml, 'text/html');

            let currentSemester = null;

            hDoc.querySelectorAll('table tbody tr').forEach(row => {
                if (row.classList.contains('table-parent-row')) {
                    const tds = row.querySelectorAll('td');
                    if (tds.length >= 8) {
                        currentSemester = {
                            term: tds[0].textContent.trim(),
                            earnedCH: tds[4].textContent.trim(),
                            sgpa: tds[6].textContent.trim(),
                            cgpa: tds[7].textContent.trim(),
                            courses: []
                        };
                        historyData.push(currentSemester);
                    }
                } else if (row.classList.contains('table-child-row') && currentSemester) {
                    const tds = row.querySelectorAll('td');
                    if (tds.length >= 4) {
                        currentSemester.courses.push({
                            name: tds[0].textContent.trim(),
                            creditHours: tds[1].textContent.trim(),
                            gradePoints: tds[2].textContent.trim(),
                            finalGrade: tds[3].textContent.trim()
                        });
                    }
                }
            });

            if (historyData.length > 0) {
                const latestSem = historyData[historyData.length - 1];
                const totalCredits = historyData.reduce((acc, sem) => acc + (parseFloat(sem.earnedCH) || 0), 0);
                statsData.cgpa = latestSem.cgpa;
                statsData.credits = totalCredits.toString();
            }

        } catch (historyError) {
            console.error(`Error scraping history:`, historyError);
        }
        return { historyData, statsData };
    };

    // ==========================================
    // TASK 3: FETCH TIMETABLE
    // ==========================================
    const scrapeTimetable = async () => {
        let timetableData = [];
        const colorPalette = ['bg-teal-500/80', 'bg-emerald-600/80', 'bg-orange-400/90', 'bg-slate-500/90', 'bg-blue-500/80', 'bg-indigo-500/80', 'bg-pink-500/80'];

        try {
            const ttResponse = await fetch('https://horizon.ucp.edu.pk/student/class/schedule'); 
            const ttHtml = await ttResponse.text();
            const ttDoc = new DOMParser().parseFromString(ttHtml, 'text/html');

            let classIdCounter = 1;

            ttDoc.querySelectorAll('a[data-start][data-end]').forEach((el) => {
                const startTime = el.getAttribute('data-start');
                const endTime = el.getAttribute('data-end');
                const em = el.querySelector('em');
                const spans = el.querySelectorAll('span');

                const instructor = em ? em.textContent.trim() : 'Unknown Instructor';
                let scrapedName = spans.length > 0 ? spans[0].textContent.trim() : 'Unknown Course';
                let room = spans.length > 2 ? spans[2].textContent.trim() : 'Unknown Room';
                room = room.replace(/\s+/g, ' ').replace(/\( /g, '(').replace(/ \)/g, ')').trim();

                let cleanScrapedName = scrapedName.replace(/\.{2,}/g, '').trim().toLowerCase();
                let resolvedName = scrapedName.replace(/\.{2,}/g, '').trim(); 
                let matchedCode = ""; 
                const isLabSession = room.toLowerCase().includes('(lab)');
                
                let bestMatch = resolvedName;
                let foundPartialMatch = false;

                for (const [url, data] of courseMap.entries()) {
                    const exactFullName = data.name;
                    const exactFullNameLower = exactFullName.toLowerCase();
                    
                    if (exactFullNameLower.startsWith(cleanScrapedName) || cleanScrapedName.startsWith(exactFullNameLower)) {
                        const isLabCourse = exactFullNameLower.includes('lab') || exactFullNameLower.includes('laboratory');
                        if (isLabSession === isLabCourse) {
                            bestMatch = exactFullName;
                            matchedCode = data.code; 
                            break; 
                        } else if (!foundPartialMatch) {
                            bestMatch = exactFullName; 
                            matchedCode = data.code; 
                            foundPartialMatch = true;
                        }
                    }
                }
                resolvedName = bestMatch;

                let day = 'Unknown';
                const parentGroup = el.closest('.cd-schedule__group');
                if (parentGroup) {
                    const dayHeader = parentGroup.querySelector('.top-info span, .cd-schedule__top-info span');
                    if (dayHeader) {
                        day = dayHeader.textContent.trim();
                    } else {
                        day = parentGroup.getAttribute('data-date') || parentGroup.id || 'Unknown';
                    }
                }

                const colorIndex = resolvedName.length % colorPalette.length;

                timetableData.push({
                    id: classIdCounter++, day: day, startTime: startTime, endTime: endTime,
                    courseName: resolvedName, courseCode: matchedCode, instructor: instructor,
                    room: room, color: colorPalette[colorIndex]
                });
            });
        } catch (ttError) {
            console.error("Error scraping timetable:", ttError);
        }
        return timetableData;
    };

    // ==========================================
    // EXECUTE ALL TASKS IN PARALLEL
    // ==========================================
    const [gradesResult, historyResult, timetableResult] = await Promise.allSettled([
        scrapeGrades(), scrapeHistory(), scrapeTimetable()
    ]);

    return { 
        portalId, 
        gradesData: gradesResult.status === 'fulfilled' ? gradesResult.value : [], 
        historyData: historyResult.status === 'fulfilled' ? historyResult.value.historyData : [], 
        statsData: historyResult.status === 'fulfilled' ? historyResult.value.statsData : { cgpa: "0.00", credits: "0", inprogressCr: exactInProgressCr.toString() }, 
        timetableData: timetableResult.status === 'fulfilled' ? timetableResult.value : [] 
    };
}