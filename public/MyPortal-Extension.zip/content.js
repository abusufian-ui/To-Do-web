chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "START_SYNC") {
        runExtraction().then(data => {
            sendToBackend(data)
                .then(() => sendResponse({ success: true }))
                .catch(err => sendResponse({ success: false, error: err.message }));
        });
        return true; 
    }
});

async function runExtraction() {
    console.log("Starting local extraction on UCP Horizon...");
    
    // --- NEW: STRICT IDENTITY EXTRACTION ---
    let portalId = null;
    // Regex matches UCP ID patterns (e.g., L1F23BSCS1329)
    // Breakdown: 1 Letter, 1 Number, 1 Letter, 2 Numbers, Letters, 3-4 Numbers
    const idRegex = /[a-zA-Z]\d[a-zA-Z]\d{2}[a-zA-Z]+\d{3,4}/i; 
    
    // UPDATED: Search the entire page body to ensure we don't miss the ID
    const pageText = document.body.innerText;
    const match = pageText.match(idRegex);
    
    if (match) {
        portalId = match[0].toUpperCase();
        console.log(`🔒 Identity Lock: Found Portal ID [${portalId}]`);
    } else {
        console.log("⚠️ Warning: Could not detect Portal ID on this page.");
    }
    // ---------------------------------------

    // 1. Get Course Links from Active Dashboard
    const courseLinks = [];
    document.querySelectorAll('a[href*="/student/course/info/"]').forEach(el => {
        let href = el.getAttribute('href');
        if (!href.startsWith('http')) href = 'https://horizon.ucp.edu.pk' + href;
        courseLinks.push(href);
    });

    console.log(`Found ${courseLinks.length} active courses.`);

    let gradesData = [];
    
    // 2. Fetch and Parse each Course Page
    for (const url of courseLinks) {
        try {
            const response = await fetch(url);
            const htmlText = await response.text();
            
            const parser = new DOMParser();
            const doc = parser.parseFromString(htmlText, 'text/html');

            const realName = doc.querySelector('.breadcrumb li:nth-child(2)')?.textContent.trim() || "Unknown Course";
            const results = [];

            doc.querySelectorAll('tr.table-parent-row').forEach(row => {
                const nameAnchor = row.querySelector('a.toggle-childrens');
                let summaryName = nameAnchor ? nameAnchor.textContent.split('\n')[0].trim() : "Unknown";
                
                const badge = row.querySelector('.uk-badge');
                if (badge) {
                    summaryName = summaryName.replace(badge.textContent, '').trim();
                }
                
                const tds = row.querySelectorAll('td');
                let summaryPercentage = tds.length >= 2 ? tds[1].textContent.trim() : "0";

                let childDetails = [];
                let nextSibling = row.nextElementSibling;
                
                while (nextSibling && !nextSibling.classList.contains('table-parent-row')) {
                    const childTds = nextSibling.querySelectorAll('td');
                    if (childTds.length >= 5) {
                        childDetails.push({
                            name: childTds[0].textContent.trim(),
                            maxMarks: childTds[1].textContent.trim(),
                            obtainedMarks: childTds[2].textContent.trim(),
                            classAverage: childTds[3].textContent.trim(),
                            percentage: childTds[4].textContent.trim()
                        });
                    }
                    nextSibling = nextSibling.nextElementSibling;
                }
                results.push({ name: summaryName, weight: badge ? badge.textContent.trim() : "", percentage: summaryPercentage, details: childDetails });
            });

            const totalBadge = doc.evaluate("//span[contains(@class, 'uk-badge') and contains(text(), '/ 100')]", doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const totalPercentage = totalBadge ? totalBadge.textContent.split('/')[0].trim() : "0";

            gradesData.push({
                courseUrl: url,
                courseName: realName,
                assessments: results,
                totalPercentage: totalPercentage
            });
            
        } catch (e) {
            console.error(`Skipped active course details for ${url}:`, e);
        }
    }

    // 3. Fetch and Parse Results History
    const historyData = [];
    let statsData = { cgpa: "0.00", credits: "0", inprogressCr: (courseLinks.length * 3).toString() };

    try {
        const historyResponse = await fetch('https://horizon.ucp.edu.pk/student/results');
        const historyHtml = await historyResponse.text();
        const hParser = new DOMParser();
        const hDoc = hParser.parseFromString(historyHtml, 'text/html');

        let currentSemester = null;

        hDoc.querySelectorAll('table tbody tr').forEach(row => {
            if (row.classList.contains('table-parent-row')) {
                const tds = row.querySelectorAll('td');
                if (tds.length >= 8) {
                    currentSemester = {
                        term: tds[0].textContent.trim(),
                        earnedCH: tds[4].textContent.trim(),
                        sgpa: tds[6].textContent.trim(),
                        cgpa: tds[7].textContent.trim(),
                        courses: []
                    };
                    historyData.push(currentSemester);
                }
            } else if (row.classList.contains('table-child-row') && currentSemester) {
                const tds = row.querySelectorAll('td');
                if (tds.length >= 4) {
                    currentSemester.courses.push({
                        name: tds[0].textContent.trim(),
                        creditHours: tds[1].textContent.trim(),
                        gradePoints: tds[2].textContent.trim(),
                        finalGrade: tds[3].textContent.trim()
                    });
                }
            }
        });

        if (historyData.length > 0) {
            const latestSem = historyData[historyData.length - 1];
            const totalCredits = historyData.reduce((acc, sem) => acc + (parseFloat(sem.earnedCH) || 0), 0);
            
            statsData.cgpa = latestSem.cgpa;
            statsData.credits = totalCredits.toString();
        }

    } catch (historyError) {
        console.error(`Error scraping history:`, historyError);
    }

    // --- UPDATED: Return portalId alongside the rest of the data ---
    return { portalId, gradesData, historyData, statsData };
}

function sendToBackend(payload) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: "SEND_TO_BACKEND", payload: payload }, (response) => {
            if (chrome.runtime.lastError) {
                return reject(new Error(chrome.runtime.lastError.message));
            }
            if (response && response.success) {
                resolve(response.data);
            } else {
                reject(new Error(response ? response.error : "Unknown background error"));
            }
        });
    });
}