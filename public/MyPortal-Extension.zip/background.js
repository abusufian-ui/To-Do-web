// --- CONFIGURATION ---
const BACKEND_URL = 'https://to-do-web-01.onrender.com';

// Initialize state on startup
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ 
        isSyncing: false, 
        lastError: false,   
        syncSuccess: false,
        errorMessage: "",
        myPortalToken: null 
    });
    
    // Create an alarm that fires every 60 minutes for silent auto-sync
    chrome.alarms.create("silentPortalSync", { periodInMinutes: 1 });
    // Keep alive alarm
    chrome.alarms.create("keepAlive", { periodInMinutes: 10 });
    console.log("⏰ Alarms created and state initialized.");
});

// --- MESSAGE LISTENER ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // Save the token when auth.js sends it from your React app
    if (request.action === "SAVE_AUTH_TOKEN") {
        chrome.storage.local.set({ myPortalToken: request.token });
        console.log("🔑 User token securely synced to extension!");
        return false;
    }

    // Clear token if the user logs out
    if (request.action === "LOGOUT_EXTENSION") {
        chrome.storage.local.set({ myPortalToken: null });
        console.log("🚪 User token cleared from extension.");
        return false;
    }

    // Triggered manually from the popup button
    if (request.action === "MANUAL_SYNC_TRIGGER") {
        executeSilentSync().then(res => sendResponse(res));
        return true; // Keep channel open for async response
    }
});

// --- ALARM LISTENER ---
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "silentPortalSync") {
        console.log("⏰ Waking up for scheduled background sync...");
        executeSilentSync();
    }
    
    if (alarm.name === "keepAlive") {
        // Ping Render to prevent sleep
        fetch(`${BACKEND_URL}/`)
            .then(() => console.log("🚀 Render Heartbeat sent."))
            .catch(() => console.log("🚀 Render Heartbeat failed."));
    }
});

// --- OFFSCREEN & SYNC LOGIC ---
async function setupOffscreenDocument(path) {
    const existingContexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [chrome.runtime.getURL(path)]
    });
    if (existingContexts.length > 0) return;

    await chrome.offscreen.createDocument({
        url: path,
        reasons: ['DOM_PARSER'],
        justification: 'Parse HTML to extract academic data silently in the background'
    });
}

async function executeSilentSync() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['myPortalToken'], async (data) => {
            const currentToken = data.myPortalToken;

            if (!currentToken) {
                chrome.storage.local.set({ 
                    isSyncing: false, lastError: true, syncSuccess: false, 
                    errorMessage: "Please log into MyPortal first to link the extension." 
                });
                resolve({ success: false, error: "No Auth Token" });
                return;
            }

            chrome.storage.local.set({ isSyncing: true, lastError: false, syncSuccess: false, errorMessage: "" });

            try {
                // 1. Create the invisible scraping window
                await setupOffscreenDocument('offscreen.html');

                // 2. Ask the offscreen script to fetch and scrape the data
                const scrapedData = await chrome.runtime.sendMessage({ action: "RUN_SCRAPE" });

                if (scrapedData && scrapedData.error) {
                     throw new Error(scrapedData.error);
                }

                // 3. Send fresh data to Render backend
                const backendResponse = await fetch(`${BACKEND_URL}/api/extension-sync`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'x-auth-token': currentToken
                    },
                    body: JSON.stringify(scrapedData)
                });

                if (!backendResponse.ok) {
                    const errorData = await backendResponse.json().catch(() => ({}));
                    throw new Error(errorData.message || `Backend rejected. Status: ${backendResponse.status}`);
                }

                const responseData = await backendResponse.json();

                chrome.storage.local.set({ 
                    isSyncing: false, lastSyncTime: Date.now(), lastError: false, syncSuccess: true, errorMessage: "" 
                });
                resolve({ success: true, data: responseData });

            } catch (error) {
                chrome.storage.local.set({ 
                    isSyncing: false, lastError: true, syncSuccess: false, errorMessage: error.message 
                });
                resolve({ success: false, error: error.message });
            } finally {
                // 4. Clean up memory
                try {
                    await chrome.offscreen.closeDocument();
                } catch(e) {
                    console.log("Offscreen document already closed.");
                }
            }
        });
    });
}