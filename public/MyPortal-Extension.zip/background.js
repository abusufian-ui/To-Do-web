// --- CONFIGURATION ---
const BACKEND_URL = 'https://to-do-web-01.onrender.com';

// Initialize state on startup
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ 
        isSyncing: false, 
        lastError: false,
        syncSuccess: false,
        errorMessage: "",
        myPortalToken: null // <--- NEW: Dynamic token storage for multi-user support
    });
    chrome.alarms.create("keepAlive", { periodInMinutes: 10 });
    console.log("⏰ Heartbeat alarm created and state initialized.");
});

// --- 1. MESSAGE LISTENER (Handles Manual & Content Script Sync) ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // --- DYNAMIC AUTHENTICATION ---
    // Save the token when auth.js sends it from your React app
    if (request.action === "SAVE_AUTH_TOKEN") {
        chrome.storage.local.set({ myPortalToken: request.token });
        console.log("🔑 User token securely synced to extension!");
        return false;
    }

    // Clear token if the user logs out of your web app
    if (request.action === "LOGOUT_EXTENSION") {
        chrome.storage.local.set({ myPortalToken: null });
        console.log("🚪 User token cleared from extension.");
        return false;
    }

    // --- DATA SYNCING ---
    if (request.action === "SEND_TO_BACKEND") {
        
        // Retrieve the dynamically saved token before syncing
        chrome.storage.local.get(['myPortalToken'], (data) => {
            const currentToken = data.myPortalToken;

            // Failsafe: Prevent syncing if no user is logged into the web app
            if (!currentToken) {
                chrome.storage.local.set({ 
                    isSyncing: false, 
                    lastError: true, 
                    syncSuccess: false,
                    errorMessage: "Please log into MyPortal first to link the extension." 
                });
                sendResponse({ success: false, error: "No Auth Token" });
                return;
            }

            // Track syncing state for the UI
            chrome.storage.local.set({ 
                isSyncing: true, 
                lastError: false,
                syncSuccess: false,
                errorMessage: ""
            });

            fetch(`${BACKEND_URL}/api/extension-sync`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-auth-token': currentToken // <--- Dynamic token used here!
                },
                body: JSON.stringify(request.payload)
            })
            .then(async response => {
                // NEW: Read the exact error message from the backend if it fails!
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(errorData.message || `Backend rejected. Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                // Update storage on success
                chrome.storage.local.set({ 
                    isSyncing: false, 
                    lastSyncTime: Date.now(), 
                    lastError: false,
                    syncSuccess: true,     // Tells UI to show green success box
                    errorMessage: ""
                });
                sendResponse({ success: true, data: data });
            })
            .catch(error => {
                // Update storage on failure
                chrome.storage.local.set({ 
                    isSyncing: false, 
                    lastError: true,
                    syncSuccess: false,
                    errorMessage: error.message  // Feeds exact error text to the UI
                });
                sendResponse({ success: false, error: error.message });
            });
        });

        return true; // Keep the message channel open for the async fetch response
    }
});

// --- 2. HEARTBEAT ALARM (Prevents UCP & Render Logout) ---
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "keepAlive") {
        // Ping UCP to keep session cookie fresh
        fetch('https://horizon.ucp.edu.pk/student/dashboard')
            .then(() => console.log("💓 UCP Heartbeat sent."))
            .catch(() => console.log("💓 UCP Heartbeat failed."));

        // Ping Render to prevent sleep (Bypasses 15-min idle rule)
        fetch(`${BACKEND_URL}/`)
            .then(() => console.log("🚀 Render Heartbeat sent."))
            .catch(() => console.log("🚀 Render Heartbeat failed."));
    }
});

// --- 3. SILENT AUTO-SYNC (Triggers on Navigation) ---
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url?.includes("student/dashboard")) {
        console.log("🚀 Dashboard detected! Triggering silent sync...");
        
        chrome.tabs.sendMessage(tabId, { action: "START_SYNC" }, (response) => {
            if (chrome.runtime.lastError) {
                console.log("Auto-sync: Content script not ready.");
            } else {
                console.log("Auto-sync success:", response);
            }
        });
    }
});