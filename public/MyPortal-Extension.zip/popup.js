function updateUI() {
    chrome.storage.local.get(['lastSyncTime', 'isSyncing', 'lastError', 'errorMessage', 'syncSuccess'], (data) => {
        const feedbackBox = document.getElementById('feedbackBox');
        const lastSync = document.getElementById('lastSync');
        const btn = document.getElementById('syncBtn');

        if (data.isSyncing) {
            feedbackBox.className = "state-syncing";
            feedbackBox.innerHTML = `<div class="spinner"></div> Syncing*`;
            btn.disabled = true;
            btn.innerText = "Processing...";
        } else if (data.lastError) {
            feedbackBox.className = "state-error";
            feedbackBox.innerHTML = `<strong>Sync Failed</strong><span class="error-text">${data.errorMessage || "Unknown error occurred."}</span>`;
            btn.disabled = false;
            btn.innerText = "Try Again";
        } else if (data.syncSuccess) {
            feedbackBox.className = "state-success";
            feedbackBox.innerHTML = `✓ Sync Successful!`;
            btn.disabled = false;
            btn.innerText = "Sync Data Now";
        } else {
            feedbackBox.className = "state-ready";
            feedbackBox.innerHTML = `Ready to sync.`;
            btn.disabled = false;
            btn.innerText = "Sync Data Now";
        }

        if (data.lastSyncTime) {
            const time = new Date(data.lastSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            lastSync.innerText = "Last synced today at " + time;
        }
    });
}

document.getElementById('syncBtn').addEventListener('click', async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab?.url?.includes("horizon.ucp.edu.pk")) {
        // Instantly trigger the loading UI
        chrome.storage.local.set({ isSyncing: true, lastError: false, syncSuccess: false });
        updateUI();

        chrome.tabs.sendMessage(tab.id, { action: "START_SYNC" }, (response) => {
            if (chrome.runtime.lastError) {
                 chrome.storage.local.set({ 
                     isSyncing: false, 
                     lastError: true, 
                     errorMessage: "Please refresh your UCP portal page and try again." 
                 });
                 updateUI();
            }
        });
    } else {
        // Handle wrong website error
        chrome.storage.local.set({ 
            isSyncing: false, 
            lastError: true, 
            errorMessage: "You must be on the UCP Horizon Dashboard." 
        });
        updateUI();
    }
});

// Refresh UI every 500ms so the animation and status changes feel snappy
setInterval(updateUI, 500);
updateUI();